package com.deroua.services;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
